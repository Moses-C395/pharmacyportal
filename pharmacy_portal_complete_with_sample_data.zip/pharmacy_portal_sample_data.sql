
USE pharmacy_portal_db;

-- Users
INSERT INTO Users (userName, contactInfo, userType) VALUES
('alice', 'alice@example.com', 'patient'),
('bob', 'bob@example.com', 'pharmacist'),
('carol', 'carol@example.com', 'patient'),
('dan', 'dan@example.com', 'pharmacist'),
('eve', 'eve@example.com', 'patient');

-- Medications
INSERT INTO Medications (medicationName, dosage, manufacturer) VALUES
('Amoxicillin', '500mg', 'Pfizer'),
('Ibuprofen', '200mg', 'Bayer'),
('Paracetamol', '500mg', 'Johnson & Johnson'),
('Lisinopril', '10mg', 'Teva'),
('Atorvastatin', '20mg', 'Mylan');

-- Prescriptions
INSERT INTO Prescriptions (userId, medicationId, prescribedDate, dosageInstructions, quantity, refillCount) VALUES
(1, 1, NOW(), 'Take one capsule every 8 hours', 30, 2),
(3, 2, NOW(), 'Take one tablet after meals', 60, 1),
(5, 3, NOW(), 'Take one tablet every 12 hours', 45, 0),
(1, 4, NOW(), 'Take one tablet daily', 30, 1),
(3, 5, NOW(), 'Take one tablet at bedtime', 30, 2);

-- Inventory
INSERT INTO Inventory (medicationId, quantityAvailable, lastUpdated) VALUES
(1, 100, NOW()),
(2, 200, NOW()),
(3, 150, NOW()),
(4, 120, NOW()),
(5, 180, NOW());

-- Sales
INSERT INTO Sales (prescriptionId, saleDate, quantitySold, saleAmount) VALUES
(1, NOW(), 30, 15.00),
(2, NOW(), 60, 20.00),
(3, NOW(), 45, 18.00),
(4, NOW(), 30, 22.00),
(5, NOW(), 30, 25.00);
