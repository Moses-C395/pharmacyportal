# Pharmacy Portal

Final Web Development Project for CIS  
Professor Yanilda Peralta Ramos — Spring 2025

---

## 📌 Overview

The Pharmacy Portal is a PHP and MySQL-based web application designed for pharmacists and patients to manage:

- User records (pharmacists, patients)
- Medications
- Prescriptions
- Inventory and sales

It uses SQL triggers, views, and stored procedures to support real-world functionality.

---

## 🚀 How to Run This Project

### Requirements:
- XAMPP (or any Apache+MySQL stack)
- Web browser

### Steps:
1. Start **Apache** and **MySQL** in XAMPP.
2. Import the database:
   - Open `phpMyAdmin`
   - Create database: `pharmacy_portal_db`
   - Import `pharmacy_portal_db.sql`
3. Copy all files into:
   ```
   C:/xampp/htdocs/pharmacyportal
   ```
4. Visit in browser:
   ```
   http://localhost/pharmacyportal
   ```
   or if using port 8888:
   ```
   http://localhost:8888/pharmacyportal
   ```

---

## 📁 Files and Features

| File                    | Description                                  |
|-------------------------|----------------------------------------------|
| `index.php`             | Homepage with forms to add records           |
| `PharmacyDatabase.php`  | Core database handler using MySQLi           |
| `add*.php`              | Add user, medication, prescription           |
| `view*.php`             | View records with Edit/Delete options        |
| `edit*.php`             | Edit existing records                        |
| `delete*.php`           | Remove records from the database             |
| `pharmacy_portal_db.sql`| Database schema and sample data              |
| `Pharmacy_Portal_Report.pdf` | Full documentation and explanation     |

---

## ✅ Report

See `Pharmacy_Portal_Report.pdf` for full technical write-up.

---

## 👨‍💻 Author

Moses Colon  
Spring 2025 — CIS Final Project
